/*
4) Crie um programa com um vetor e uma matriz. No vetor armazene o nome de 6 alunos.
Na matriz armazene 3 notas para cada aluno. Após preenchidos, apresente uma listagem
com os nomes dos alunos, sua média e se o mesmo está aprovado ou reprovado
(considere 6 ou mais como a nota para ser aprovado).
 */
package matriz.ex4;

import java.util.Scanner;

public class MatrizEx4 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
 String[] nomes = new String[6];
        double[][] notas = new double[6][3];
        for (int i = 0; i < 6; i++) {
            System.out.print("Nome do aluno " + (i + 1) + ": ");
            nomes[i] = teclado.nextLine();

            for (int j = 0; j < 3; j++) {
                System.out.print("Nota " + (j + 1) + ": ");
                notas[i][j] = teclado.nextDouble();
            }
             teclado.nextLine(); 
        }
        for (int i = 0; i < 6; i++) {
            double soma = 0;
            for (int j = 0; j < 3; j++) {
                soma = soma + notas[i][j];
            }
            double media = soma / 3;
            if (media >= 6.0) {
                System.out.println(nomes[i] + "Media: " + media + " foi APROVADO");
            } else {
                System.out.println(nomes[i] + "Media: " + media + " foi REPROVADO");
            }
        }
    }

}
