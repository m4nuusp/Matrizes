/*
4) Crie um programa com um vetor e uma matriz. No vetor armazene o nome de 6 alunos.
Na matriz armazene 3 notas para cada aluno. Após preenchidos, apresente uma listagem
com os nomes dos alunos, sua média e se o mesmo está aprovado ou reprovado
(considere 6 ou mais como a nota para ser aprovado).
 */
package matriz.ex4;

import java.util.Scanner;

public class MatrizEx4 {
    
    public static void main(String[] args) {
        Scanner teclado = new Scanner (System.in);
        int tamanhonome=6, tamanholinha=6, tamanhocoluna=3, cont =0, tamanhonota=0;
        String vetalunos[] = new String[tamanhonome];
        double matriznotas[][] = new double[tamanholinha][tamanhocoluna];
        double media;
        for (int i = 0; i < tamanhonome; i++) {
            System.out.println("Digite um nome");
            vetalunos[i] = teclado.nextLine();
        }
        
        for (int linha = 0; linha < tamanholinha; linha++) {
            for (int coluna = 0; coluna < tamanhocoluna; coluna++) {
                System.out.println("Digite as notas do aluno(a): " + vetalunos[cont]);
                matriznotas[linha][coluna] = teclado.nextDouble();
                //tamanhonota++;
                //if (3 ==tamanhonota) {
                  //tamanhonota=0;
                   //cont++;
                //}
            }
        }
         tamanhonota=0;
        double acumnotas[] = new double[6];
        for (int linha = 0; linha < tamanholinha; linha++) {
            for (int coluna = 0; coluna < tamanhocoluna; coluna++) {
               acumnotas[linha] = matriznotas[linha][coluna] + acumnotas[linha]; 
              //  if (3==tamanhonota) {
                   // tamanhonota=0; 
                //}
            }
        }
        
        cont= 0;
        for (int linha = 0; linha <6; linha++) {
          acumnotas[linha] = acumnotas[linha]/3;  
           if (acumnotas[linha]>=6) {
                System.out.println("aluno(a) " + vetalunos[cont] + " com a media "+  acumnotas[linha] + " esta aprovado" );
            } else {
               System.out.println("aluno(a) " + vetalunos[cont] + " com a media "+  acumnotas[linha] + " esta reprovado" );
           }
           cont++;
        }
       
    }
    
}
