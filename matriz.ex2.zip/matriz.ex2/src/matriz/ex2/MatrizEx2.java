/*
 * Crie um programa com uma matriz 3x3 numérica, que é preenchida pelo usuário, e que
após preenchida, procure o menor elemento na matriz e o apresente na tela.
 */
package matriz.ex2;

import java.util.Scanner;

public class MatrizEx2 {

    public static void main(String[] args) {
       Scanner teclado = new Scanner(System.in);
       int tamanho =3, menor;
       int matriznum [][] = new int[tamanho][tamanho];
        for (int linha = 0; linha < tamanho; linha++) {
            for (int coluna = 0; coluna < tamanho; coluna++) {
                System.out.println("Digite um numero");
                matriznum[linha][coluna] = teclado.nextInt();
            }
        }
         menor = matriznum[0][0];
        for (int linha = 0; linha < tamanho; linha++) {
            for (int coluna = 0; coluna < tamanho; coluna++) {
               
                if (menor>matriznum[linha][coluna]) {
                   menor = matriznum[linha][coluna];
                }
            }
        }
        System.out.println("O menor numero e " +  menor);
    }
    
}
