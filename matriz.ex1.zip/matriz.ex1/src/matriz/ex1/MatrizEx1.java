/*
 * 1) Crie um programa com uma matriz 5x5, que é preenchida pelo usuário e em seguida a
apresente na tela.
 * 
 */
package matriz.ex1;

import java.util.Scanner;

public class MatrizEx1 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int tamanho = 2;
        String ordemmatriz [][] = new String[tamanho][tamanho];
        
        for (int linha = 0; linha < tamanho; linha++) {
            for (int coluna = 0; coluna < tamanho; coluna++) {
                System.out.println("Informe um nome de um personagem de ordem paranormal");
                ordemmatriz[linha][coluna] = teclado.nextLine();
            }
        }
        for (int linha = 0; linha < tamanho; linha++) {
            System.out.println(" ");
            for (int coluna = 0; coluna < tamanho; coluna++) {
                System.out.print(ordemmatriz[linha][coluna] + " ");
            }
  
        }
    }

}
