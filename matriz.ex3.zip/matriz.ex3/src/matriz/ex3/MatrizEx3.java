/*
 3) Crie um programa com duas matrizes matriz 2x2. Uma é preenchida pelo usuário.
Depois de preenchida encontre o maior elemento. Na segunda matriz armazene o
resultado da multiplicação de cada elemento da primeira matriz pelo maior elemento.
Apresente a matriz resultante.
 */
package matriz.ex3;

import java.util.Scanner;

public class MatrizEx3 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        int tamanholinha = 2, tamanhocoluna =2, maior;
        int matriznum [][] = new int [tamanholinha][tamanhocoluna];
        int matriznum2 [][]= new int [tamanholinha][tamanhocoluna];
        
        for (int linha = 0; linha < tamanholinha; linha++) {
            for (int coluna = 0; coluna < tamanhocoluna; coluna++) {
                System.out.println("Digite um numero"); 
                matriznum[linha][coluna] = teclado.nextInt();
            }
        }
        maior = matriznum[0][0];
        for (int linha = 0; linha < tamanholinha; linha++) {
            for (int coluna = 0; coluna < tamanhocoluna; coluna++) {
                if (maior<matriznum[linha][coluna]) {
                    maior = matriznum [linha] [coluna];
                }
 
            }
        }
            for (int linhas = 0; linhas < tamanholinha; linhas++) {
                for (int colunas = 0; colunas < tamanhocoluna; colunas++) {
                    matriznum2[linhas][colunas] = matriznum[linhas][colunas] * maior;
                }
            }
            for (int linhas = 0; linhas < tamanholinha; linhas++) {
                System.out.println(" ");
                for (int colunas = 0; colunas < tamanhocoluna; colunas++) {
                    System.out.println( "Os resultados sao: "  + matriznum2[linhas][colunas] +"");
                }
 
            }
            
        }
    }


