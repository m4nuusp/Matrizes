/*
 6) Crie um programa que preencha uma matriz 15x5 com números inteiros. Determine e
apresente quais números se repetem e quantas vezes.
 */
package matriz.ex6;
import java.util.Scanner;

public class MatrizEx6 {

    public static void main(String[] args) {
       Scanner teclado = new Scanner(System.in);
       int tamanho1 =2, tamanho2 =2, cont=0;
       int matriznum[][] = new int[tamanho1][tamanho2];
       
       
        for (int i = 0; i < tamanho1; i++) {
            for (int j = 0; j < tamanho2; j++) {
                System.out.println("Digite um numero inteiro:");
                matriznum[i][j] = teclado.nextInt();
            }
        }
        
        int igual = matriznum[0][0];
        int iguale[]=new int[4];
        
        for (int i = 0; i < tamanho1; i++) {
            for (int j = 0; j < tamanho2; j++) {
                if (matriznum[i][j]==igual) {
                    igual = matriznum[i][j];
                    iguale[i] = igual;
                    cont++;
                    
                } 
            }
 
        } for (int i = 0; i < tamanho1; i++) {
            for (int j = 0; j < tamanho2; j++) {
                     System.out.println("o numero " + iguale[i] + " se repete " + cont + " vezes");     
        }
        }

       
              
            
    }
    
}
