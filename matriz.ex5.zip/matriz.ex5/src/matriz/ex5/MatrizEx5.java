/*
5) Faça um programa que preencha:
- um vetor com nome de 4 lojas;
- um vetor com nome de 6 produtos;
- uma matriz com os preços de cada produto em cada loja;
Em seguida apresente uma listagem (Loja – produto) dos produtos acima de R$ 50,00.
 */
package matriz.ex5;

import java.util.Scanner;

public class MatrizEx5 {

    public static void main(String[] args) {
        Scanner teclado = new Scanner (System.in);
        int nomelojas = 4, nomeprodutos = 6, cont=1, cont2 = 0;
        String vetlojas[] = new String[nomelojas];
        String vetprodutos[] = new String[nomeprodutos];
        double matrizvalor[][] = new double[nomelojas][nomeprodutos];
        
        for (int i = 0; i < nomelojas; i++) {
            System.out.println("Digite o nome da " +cont+ "a loja:"); 
            vetlojas[i] = teclado.nextLine();
            cont++;
        }
         cont = 1;
        for (int i = 0; i < nomeprodutos; i++) {
            System.out.println("Digite o nome do " + cont+"o produto:");
            vetprodutos[i] = teclado.nextLine();
            cont++;
        }
         cont = 0;
        for (int i = 0; i < nomelojas; i++) {
            for (int j = 0; j < nomeprodutos; j++) {
                System.out.println("Digite o valor do "+ vetprodutos[cont2] + " produto da "+ vetlojas[cont] +" loja");
                matrizvalor[i][j] = teclado.nextDouble();
                cont2++;
                if (cont2>5) {
                  cont++;
                  cont2=0;
                }
            }
   
        }
        for (int i = 0; i < nomelojas; i++) {
            for (int j = 0; j < nomeprodutos; j++) {
                if (matrizvalor[i][j]>50) {
                    System.out.println("Loja " +vetlojas[i] + "tem o valor do produto "+ vetprodutos[j] + " maior que 50.");
                }
            }
 
        }
    }
    
}
