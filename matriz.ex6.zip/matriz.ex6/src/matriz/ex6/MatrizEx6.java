/*
 6) Crie um programa que preencha uma matriz 15x5 com números inteiros. Determine e
apresente quais números se repetem e quantas vezes.
 */
package matriz.ex6;

import java.util.Scanner;

public class MatrizEx6 {

    public static void main(String[] args) {
         Scanner teclado = new Scanner(System.in);
        int tamanho1 = 15, tamanho2 = 5;
        int matriznum[][] = new int[tamanho1][tamanho2];

        for (int i = 0; i < tamanho1; i++) {
            for (int j = 0; j < tamanho2; j++) {
                System.out.println("Digite um numero inteiro:");
                matriznum[i][j] = teclado.nextInt();
            }
        }

        for (int i = 0; i < tamanho1; i++) {
            for (int j = 0; j < tamanho2; j++) {

                int cont = 0;
                int repetido = 0;

                for (int x = 0; x < i; x++) {
                    for (int y = 0; y < tamanho2; y++) {
                        if (matriznum[x][y] == matriznum[i][j]) {
                            repetido++;
                        }
                    }
                }

                for (int y = 0; y < j; y++) {
                    if (matriznum[i][y] == matriznum[i][j]) {
                        repetido++;
                    }
                }

                if (repetido == 0) {
                    for (int x = 0; x < tamanho1; x++) {
                        for (int y = 0; y < tamanho2; y++) {
                            if (matriznum[x][y] == matriznum[i][j]) {
                                cont++;
                            }
                        }
                    }

                    if (cont > 1) {
                        System.out.println("O numero "
                                + matriznum[i][j]
                                + " se repete " + cont + " vezes.");
                    }
                }
            }
        }
    }
}