/*
7) Faça um programa com vetores e matrizes, que atenda o seguinte menu descrito a
seguir. Considere como 40 alunos e 10 disciplinas a capacidade máxima do programa.
Menu:
1 – Cadastrar um nome Disciplina (vetor)
2 – Cadastrar um nome de Aluno (vetor)
3 – Cadastrar uma Média de aluno em disciplina (matriz)
4 – Listar disciplinas;
5 – Listar alunos;
6 – listar alunos e respectiva média em determinada disciplina;
0 – Sair
 */
package matriz.ex7;

import java.util.Scanner;

public class MatrizEx7 {

    public static void main(String[] args) {
      Scanner teclado = new Scanner(System.in); 
      int tamanhodisciplina = 10,tamanhoaluno = 40, linha = 10, coluna = 40, opcao = 1, cont =0, cont2=0;
      String vetdisciplina[] = new String[tamanhodisciplina];
      String vetalunos[] = new String[tamanhoaluno];
      double matrizmedia[][] = new double[linha][coluna];
      
        
        while (opcao != 0) { 
            System.out.println("///////////////////////////////////////////////////////////");
        System.out.println("Menu:");
        System.out.println("1 - Cadastrar uma Disciplina");
        System.out.println("2 - Cadastrar um(a) aluno(a)");
        System.out.println("3 - Cadastrar a media de um aluno em uma disciplina");
        System.out.println("4 - Listar disciplinas");
        System.out.println("5 - Listar alunos");
        System.out.println("6 - Listar alunos e respectiva media em determinada disciplina");
        System.out.println("0 - Sair");
            System.out.println("///////////////////////////////////////////////////////////");
        opcao = teclado.nextInt();
        teclado.nextLine();
            if (opcao == 1) {
                for (int i = 0; i < tamanhodisciplina; i++) {
                    System.out.println("Digite aqui para cadastrar uma Disciplina");
                    vetdisciplina[i] = teclado.nextLine();
                }
            } else if (opcao == 2) {
                for (int i = 0; i < tamanhoaluno; i++) {
                    System.out.println("Digite aqui para cadastrar um Aluno");  
                    vetalunos[i] = teclado.nextLine();
                }
            } else if (opcao == 3) {
                for (int i = 0; i < tamanhodisciplina; i++) {
                    for (int j = 0; j < tamanhoaluno; j++) {
                        System.out.println("Digite aqui para cadastrar a media do aluno(a) " + vetalunos[j] + " da disciplina " + vetdisciplina[i]);
                        matrizmedia[i][j] = teclado.nextDouble();
                        cont2++;
                        if (cont2>1) {
                            cont2=0;
                           cont++; 
                        }
                    }
                }
            } else if (opcao == 4) {
                teclado.nextLine();
                System.out.println("Lista de disciplinas:");
                for (int i = 0; i < tamanhodisciplina; i++) {
                    System.out.println(vetdisciplina[i]);   
                }
            } else if (opcao == 5) {
                System.out.println("Lista de alunos:");
                for (int i = 0; i < tamanhoaluno; i++) {
                    System.out.println(vetalunos[i]); 
                }
            } else if (opcao == 6) {
                for (int i = 0; i < tamanhodisciplina; i++) {
                    for (int j = 0; j < tamanhoaluno; j++) {
                        System.out.println("O Aluno(a) " + vetalunos[j] + " na disciplina " + vetdisciplina[i] + " tem como media " + matrizmedia[i][j]);  
                    }
  
                }
            }
            
        
        }
        
    }
    
}
